#!/usr/bin/env python3
# -*- coding: utf-8 -*-
SERVER_PORT = 8081
DEBUG = True
SQLALCHEMY_ECHO = True